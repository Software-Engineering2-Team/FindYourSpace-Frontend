export const userManagementUsers = [
    {
      "id": 1,
      "username": "john_doe",
      "first_name": "John",
      "last_name": "Doe",
      "email": "john.doe@example.com",
      "date_joined": "2023-04-20 08:00:00",
      "contact_info": "+1234567890"
    },
    {
      "id": 2,
      "username": "jane_smith",
      "first_name": "Jane",
      "last_name": "Smith",
      "email": "jane.smith@example.com",
      "date_joined": "2023-05-15 10:30:00",
      "contact_info": "+1987654321"
    },
    {
      "id": 3,
      "username": "alice_johnson",
      "first_name": "Alice",
      "last_name": "Johnson",
      "email": "alice.johnson@example.com",
      "date_joined": "2023-06-10 12:45:00",
      "contact_info": "+1122334455"
    },
]
