export const spaces = [
    {
      "id": 1,
      "location": "Warsaw",
      "size": 100,
      "price": 48,
      "owner_id": "2564",
    },
    {
        "id": 2,
        "location": "Wroclaw",
        "size": 100,
        "price": 50,
        "owner_id": "2565",
    },
    {
        "id": 1,
        "location": "Poznan",
        "size": 100,
        "price": 105,
        "owner_id": "2566",
    },
]
